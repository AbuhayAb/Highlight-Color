# Highlight-Color
A project for Large software course
#Getting Started

#Prerequisites


#Installing

#Running the tests

#Break down into end to end tests


#And coding style tests


#Deployment

#Built With



#Contributing

Please read CONTRIBUTING.md for details on our code of conduct, and the process for submitting pull requests to us.
#Versioning

#Authors

    Abuhay Abune 

#License

This project is licensed under the MIT License - see the LICENSE.md file for details
#Acknowledgments


